'use client'

import { useState, useTransition } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get('redirect') ?? '/dashboard'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    startTransition(async () => {
      const supabase = createClient()
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password })

      if (authError) {
        setError('E-mail ou senha incorretos. Tente novamente.')
        return
      }

      await fetch('/api/auth/audit-login', { method: 'POST' })
      router.push(redirect)
      router.refresh()
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div>
        <label htmlFor="email" className="block text-sm font-medium mb-1" style={{ color: 'var(--color-medium)' }}>
          E-mail
        </label>
        <input
          id="email" type="email" required autoComplete="email"
          value={email} onChange={(e) => setEmail(e.target.value)}
          className="w-full px-3 py-2 rounded-lg text-sm outline-none transition focus:ring-2 focus:ring-[var(--color-primary)]"
          style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-dark)' }}
        />
      </div>

      <div>
        <label htmlFor="password" className="block text-sm font-medium mb-1" style={{ color: 'var(--color-medium)' }}>
          Senha
        </label>
        <input
          id="password" type="password" required autoComplete="current-password"
          value={password} onChange={(e) => setPassword(e.target.value)}
          className="w-full px-3 py-2 rounded-lg text-sm outline-none transition focus:ring-2 focus:ring-[var(--color-primary)]"
          style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-dark)' }}
        />
      </div>

      {error && (
        <p className="text-sm rounded-lg px-3 py-2" style={{ backgroundColor: '#FEE2E2', color: 'var(--color-danger)', border: '1px solid #FECACA' }}>
          {error}
        </p>
      )}

      <button
        type="submit" disabled={isPending}
        className="w-full py-2.5 rounded-lg text-sm font-semibold transition disabled:opacity-60 mt-2 hover:opacity-90 active:scale-[0.98]"
        style={{ backgroundColor: 'var(--color-primary)', color: '#FFFFFF' }}
      >
        {isPending ? 'Entrando…' : 'Entrar'}
      </button>
    </form>
  )
}
