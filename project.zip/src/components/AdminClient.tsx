'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import type { PortalSettings, AuditLog } from '@/types/database'

interface Props {
  settings: PortalSettings | null
  userEmail: string
}

export default function AdminClient({ settings, userEmail }: Props) {
  const router = useRouter()

  const [portalTitle, setPortalTitle] = useState(settings?.portal_title ?? '')
  const [reportId, setReportId] = useState(settings?.report_id ?? '')
  const [embedUrl, setEmbedUrl] = useState(settings?.embed_url ?? '')
  const [activeMode, setActiveMode] = useState<'report_id' | 'embed_url'>(settings?.active_mode ?? 'report_id')
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null)
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [logsLoading, setLogsLoading] = useState(true)

  useEffect(() => {
    fetch('/api/audit-logs')
      .then((r) => r.json())
      .then(({ logs }) => setLogs(logs ?? []))
      .finally(() => setLogsLoading(false))
  }, [])

  const handleSave = useCallback(async () => {
    setSaving(true)
    setSaveMsg(null)
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ portal_title: portalTitle, report_id: reportId, embed_url: embedUrl, active_mode: activeMode }),
    })
    setSaving(false)
    if (res.ok) {
      setSaveMsg({ type: 'ok', text: 'Configurações salvas com sucesso!' })
      router.refresh()
    } else {
      const { error } = await res.json()
      setSaveMsg({ type: 'err', text: error ?? 'Erro ao salvar.' })
    }
  }, [portalTitle, reportId, embedUrl, activeMode, router])

  const handleLogout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/login')
    router.refresh()
  }, [router])

  const eventLabel: Record<string, string> = {
    login: '🔑 Login',
    logout: '🚪 Logout',
    dashboard_access: '📊 Acesso ao dashboard',
    settings_update: '⚙️ Configuração alterada',
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-bg)' }}>
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-3 shadow-sm"
        style={{ backgroundColor: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
        <div className="flex items-center gap-3">
          <Image src="/logo_cor.png" alt="B3.Pet" width={110} height={36} className="object-contain" />
          <span className="text-xs font-semibold px-2 py-0.5 rounded"
            style={{ backgroundColor: 'var(--color-primary)', color: '#fff' }}>
            Admin
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden md:block text-xs" style={{ color: 'var(--color-light)' }}>{userEmail}</span>
          <button onClick={() => router.push('/dashboard')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium transition hover:opacity-80"
            style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-medium)' }}>
            ← Dashboard
          </button>
          <button onClick={handleLogout}
            className="px-3 py-1.5 rounded-lg text-xs font-medium transition hover:opacity-80"
            style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-medium)' }}>
            Sair
          </button>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full flex flex-col gap-6">
        <h1 className="text-lg font-semibold" style={{ color: 'var(--color-dark)' }}>Configurações do Portal</h1>

        {/* Settings card */}
        <div className="rounded-2xl p-6 flex flex-col gap-5"
          style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>

          <Field label="Título do portal">
            <input value={portalTitle} onChange={(e) => setPortalTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-dark)' }} />
          </Field>

          <Field label="Modo de embed">
            <div className="flex gap-3">
              {(['report_id', 'embed_url'] as const).map((mode) => (
                <label key={mode} className="flex items-center gap-2 cursor-pointer text-sm" style={{ color: 'var(--color-dark)' }}>
                  <input type="radio" name="activeMode" value={mode} checked={activeMode === mode}
                    onChange={() => setActiveMode(mode)} className="accent-[var(--color-primary)]" />
                  {mode === 'report_id' ? 'Report ID (template)' : 'URL completa'}
                </label>
              ))}
            </div>
          </Field>

          {activeMode === 'report_id' && (
            <Field label="Report ID" hint="Ex.: AbCdEf1234... (parte após ?r= no link Publish to web)">
              <input value={reportId} onChange={(e) => setReportId(e.target.value)} placeholder="AbCdEf1234..."
                className="w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[var(--color-primary)] font-mono"
                style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-dark)' }} />
            </Field>
          )}

          {activeMode === 'embed_url' && (
            <Field label="Embed URL completa" hint="Cole a URL completa do Power BI Publish to web">
              <input value={embedUrl} onChange={(e) => setEmbedUrl(e.target.value)}
                placeholder="https://app.powerbi.com/view?r=..."
                className="w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[var(--color-primary)] font-mono"
                style={{ backgroundColor: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-dark)' }} />
            </Field>
          )}

          {saveMsg && (
            <p className="text-sm rounded-lg px-3 py-2"
              style={{
                backgroundColor: saveMsg.type === 'ok' ? '#DCFCE7' : '#FEE2E2',
                color: saveMsg.type === 'ok' ? 'var(--color-success)' : 'var(--color-danger)',
                border: `1px solid ${saveMsg.type === 'ok' ? '#86EFAC' : '#FECACA'}`,
              }}>
              {saveMsg.text}
            </p>
          )}

          <div className="flex justify-end">
            <button onClick={handleSave} disabled={saving}
              className="px-5 py-2 rounded-lg text-sm font-semibold transition hover:opacity-90 disabled:opacity-60"
              style={{ backgroundColor: 'var(--color-primary)', color: '#fff' }}>
              {saving ? 'Salvando…' : 'Salvar configurações'}
            </button>
          </div>
        </div>

        {/* Preview */}
        {(activeMode === 'report_id' ? reportId : embedUrl) && (
          <div className="rounded-2xl overflow-hidden"
            style={{ border: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
            <p className="px-4 py-2 text-xs font-medium" style={{ color: 'var(--color-medium)', borderBottom: '1px solid var(--color-border)' }}>
              Preview (apenas visual — embed real)
            </p>
            <div style={{ height: '320px', position: 'relative' }}>
              <iframe
                src={activeMode === 'report_id'
                  ? `https://app.powerbi.com/view?r=${encodeURIComponent(reportId)}`
                  : embedUrl}
                className="w-full h-full border-0"
                title="Preview Power BI"
                allowFullScreen
                sandbox="allow-scripts allow-same-origin allow-popups"
              />
            </div>
          </div>
        )}

        {/* Audit Logs */}
        <div className="rounded-2xl p-6"
          style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>
          <h2 className="text-base font-semibold mb-4" style={{ color: 'var(--color-dark)' }}>
            Últimos 20 eventos de auditoria
          </h2>

          {logsLoading ? (
            <div className="flex flex-col gap-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton h-8 w-full" />
              ))}
            </div>
          ) : logs.length === 0 ? (
            <p className="text-sm" style={{ color: 'var(--color-light)' }}>Nenhum evento registrado ainda.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs" style={{ color: 'var(--color-dark)', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-medium)', fontWeight: 600 }}>
                    <th className="text-left px-3 py-2 rounded-l">Evento</th>
                    <th className="text-left px-3 py-2">Usuário</th>
                    <th className="text-left px-3 py-2 rounded-r">Data/Hora</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id} className="border-t" style={{ borderColor: 'var(--color-border)' }}>
                      <td className="px-3 py-2">{eventLabel[log.event] ?? log.event}</td>
                      <td className="px-3 py-2" style={{ color: 'var(--color-medium)' }}>{log.user_email ?? '—'}</td>
                      <td className="px-3 py-2" style={{ color: 'var(--color-light)' }}>
                        {new Date(log.created_at).toLocaleString('pt-BR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium" style={{ color: 'var(--color-medium)' }}>{label}</label>
      {children}
      {hint && <p className="text-xs" style={{ color: 'var(--color-light)' }}>{hint}</p>}
    </div>
  )
}
