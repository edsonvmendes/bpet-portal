import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Acesso Negado — B3.Pet Analytics',
  robots: { index: false, follow: false },
}

export default function AccessDeniedPage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-page px-4">
      <div className="text-center max-w-sm">
        <div className="text-6xl mb-4">🔒</div>
        <h1 className="text-xl font-semibold text-foreground mb-2">Acesso Negado</h1>
        <p className="text-sm text-muted mb-6">
          Você não tem permissão para acessar esta página.
        </p>
        <Link
          href="/dashboard"
          className="inline-block px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary-dark transition"
        >
          Voltar ao Dashboard
        </Link>
      </div>
    </main>
  )
}
