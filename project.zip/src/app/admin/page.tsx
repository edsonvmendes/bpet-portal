import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import AdminClient from '@/components/AdminClient'
import type { PortalSettings } from '@/types/database'

export const metadata = {
  title: 'Admin — B3.Pet Analytics',
  robots: { index: false, follow: false },
}

export default async function AdminPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'admin') redirect('/acesso-negado')

  const { data: settings } = await supabase
    .from('portal_settings')
    .select('*')
    .eq('id', 1)
    .single<PortalSettings>()

  return <AdminClient settings={settings} userEmail={user.email ?? ''} />
}
