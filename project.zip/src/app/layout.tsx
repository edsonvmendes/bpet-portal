import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: process.env.NEXT_PUBLIC_PORTAL_NAME ?? 'B3.Pet Analytics',
  description: 'Portal de relatórios B3.Pet',
  robots: { index: false, follow: false }, // não indexar o portal
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}
