import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { logAuditEvent } from '@/lib/audit'

export async function POST() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (user) {
    await logAuditEvent({ userId: user.id, userEmail: user.email, event: 'logout' })
  }
  await supabase.auth.signOut()
  return NextResponse.json({ ok: true })
}
