import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { logAuditEvent } from '@/lib/audit'
import { buildEmbedUrl } from '@/lib/powerbi'
import DashboardClient from '@/components/DashboardClient'
import type { PortalSettings } from '@/types/database'

export const metadata = {
  title: 'Dashboard — B3.Pet Analytics',
  robots: { index: false, follow: false },
}

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  // Busca configurações do portal
  const { data: settings } = await supabase
    .from('portal_settings')
    .select('*')
    .eq('id', 1)
    .single<PortalSettings>()

  // Grava acesso ao dashboard
  await logAuditEvent({ userId: user.id, userEmail: user.email, event: 'dashboard_access' })

  const embedUrl = settings
    ? buildEmbedUrl({
        activeMode: settings.active_mode,
        reportId: settings.report_id,
        embedUrl: settings.embed_url,
      })
    : null

  return (
    <DashboardClient
      userEmail={user.email ?? ''}
      portalTitle={settings?.portal_title ?? 'B3.Pet Analytics'}
      embedUrl={embedUrl}
    />
  )
}
