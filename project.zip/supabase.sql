-- =============================================================================
-- B3.Pet Portal — Supabase SQL Migration
-- Execute este script no SQL Editor do seu projeto Supabase
-- =============================================================================

-- ─── Extensions ──────────────────────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ─── user_profiles ───────────────────────────────────────────────────────────
create table if not exists public.user_profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  role        text not null default 'viewer' check (role in ('admin', 'viewer')),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Trigger: cria perfil automaticamente no signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.user_profiles (id, email, role)
  values (new.id, new.email, 'viewer');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ─── portal_settings (single-row) ────────────────────────────────────────────
create table if not exists public.portal_settings (
  id            int primary key default 1 check (id = 1), -- garante single-row
  portal_title  text not null default 'B3.Pet Analytics',
  report_id     text,
  embed_url     text,
  active_mode   text not null default 'report_id' check (active_mode in ('report_id', 'embed_url')),
  updated_at    timestamptz not null default now(),
  updated_by    uuid references auth.users(id)
);

-- Insere a row inicial se não existir
insert into public.portal_settings (id)
values (1)
on conflict (id) do nothing;

-- ─── audit_logs ──────────────────────────────────────────────────────────────
create table if not exists public.audit_logs (
  id          bigserial primary key,
  user_id     uuid references auth.users(id) on delete set null,
  user_email  text,
  event       text not null,        -- 'login' | 'logout' | 'dashboard_access' | 'settings_update'
  meta        jsonb,                -- dados extras (before/after, ip, etc.)
  created_at  timestamptz not null default now()
);

-- ─── RLS ─────────────────────────────────────────────────────────────────────
alter table public.user_profiles    enable row level security;
alter table public.portal_settings  enable row level security;
alter table public.audit_logs       enable row level security;

-- user_profiles
create policy "Users can read own profile"
  on public.user_profiles for select
  using (auth.uid() = id);

create policy "Admins can read all profiles"
  on public.user_profiles for select
  using (
    exists (
      select 1 from public.user_profiles up
      where up.id = auth.uid() and up.role = 'admin'
    )
  );

-- portal_settings: todos autenticados leem; só admin atualiza
create policy "Authenticated users can read settings"
  on public.portal_settings for select
  using (auth.role() = 'authenticated');

create policy "Admins can update settings"
  on public.portal_settings for update
  using (
    exists (
      select 1 from public.user_profiles up
      where up.id = auth.uid() and up.role = 'admin'
    )
  );

-- audit_logs: admin lê; inserts via service_role (server actions)
create policy "Admins can read audit logs"
  on public.audit_logs for select
  using (
    exists (
      select 1 from public.user_profiles up
      where up.id = auth.uid() and up.role = 'admin'
    )
  );

-- Inserts usam SUPABASE_SERVICE_ROLE_KEY (bypass RLS no server)
-- portanto não precisamos de policy de insert para anon/authenticated

-- ─── Índices úteis ───────────────────────────────────────────────────────────
create index if not exists audit_logs_created_at_idx on public.audit_logs (created_at desc);
create index if not exists audit_logs_user_id_idx    on public.audit_logs (user_id);

-- =============================================================================
-- Para criar o primeiro admin manualmente:
-- 1. Crie o usuário via Supabase Auth (Authentication > Users > Invite)
--    OU pelo script abaixo (substitua o email/UUID após criar via Auth UI)
-- 2. Execute:
--    UPDATE public.user_profiles SET role = 'admin' WHERE email = 'seu@email.com';
-- =============================================================================
